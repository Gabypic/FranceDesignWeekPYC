<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Site Vitrine</title>
    <link rel="stylesheet" href="/site_vitrine/css/style.css">
</head>
<body>
    <header>
        <h1>Site de Presse</h1>
        <nav>
            <a href="/site_vitrine/">Accueil</a>
            <a href="/site_vitrine/contact.php">Contact</a>
        </nav>
    </header>
    <main>

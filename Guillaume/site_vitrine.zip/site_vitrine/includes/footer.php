    </main>
    <footer>
        <p>&copy; <?= date('Y') ?> - Tous droits réservés</p>
    </footer>
</body>
</html>
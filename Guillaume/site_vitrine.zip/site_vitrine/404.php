<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Page introuvable</title>
</head>
<body>
    <h1>Erreur 404</h1>
    <p>La page demandée n'existe pas.</p>
    <a href="/site_vitrine/">Retour à l'accueil</a>
</body>
</html>
